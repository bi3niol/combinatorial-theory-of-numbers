﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CombinatorialTheoryOfNumbers.LibDotNet
{
    public interface IPlayer
    {
        void Clear();
    }
}
