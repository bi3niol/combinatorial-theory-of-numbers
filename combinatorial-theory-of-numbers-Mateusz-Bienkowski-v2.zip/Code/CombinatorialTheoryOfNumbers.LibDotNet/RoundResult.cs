﻿namespace CombinatorialTheoryOfNumbers.LibDotNet
{
    public struct RoundResult<P1Res,P2Res>
    {
        public P1Res Player1Result { get; set; }
        public P2Res Player2Result { get; set; }
    }
}